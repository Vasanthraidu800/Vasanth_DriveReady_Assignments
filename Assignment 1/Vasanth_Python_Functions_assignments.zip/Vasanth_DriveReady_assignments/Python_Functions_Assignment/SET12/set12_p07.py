# Output:
# <b><i>Hello</i></b>
# <i><b>Hello</b></i>


def bold(func):
    def wrapper():
        return f"<b>{func()}</b>"
    return wrapper


def italic(func):
    def wrapper():
        return f"<i>{func()}</i>"
    return wrapper


@bold
@italic
def text():
    return "Hello"


@italic
@bold
def text2():
    return "Hello"


print(text())
print(text2())