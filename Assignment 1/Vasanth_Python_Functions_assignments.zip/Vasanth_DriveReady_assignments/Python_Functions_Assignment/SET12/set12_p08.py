# Output:
# Without cache: fib(35) took about 3 seconds
# With cache: fib(35) took about 0.0000 seconds
# With cache: fib(100) = 354224848179261915075


import time


# Custom cache decorator
def cache(func):
    saved = {}

    def wrapper(n):
        if n not in saved:
            saved[n] = func(n)
        return saved[n]

    return wrapper


@cache
def fib(n):
    if n <= 1:
        return n

    return fib(n - 1) + fib(n - 2)


# Without cache example (remove @cache to test)
start = time.time()
print(fib(35))
end = time.time()

print(f"With cache: fib(35) took {end - start:.4f} seconds")


start = time.time()
print(fib(100))
end = time.time()

print(f"With cache: fib(100) took {end - start:.4f} seconds")