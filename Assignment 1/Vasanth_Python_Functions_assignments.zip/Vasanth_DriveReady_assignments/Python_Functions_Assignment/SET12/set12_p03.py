# Output:
# [TIMER] slow_sum took 0.0201s
# 499999500000


import time


def timer(func):
    def wrapper(*args, **kwargs):
        start = time.time()

        result = func(*args, **kwargs)

        end = time.time()

        print(f"[TIMER] {func.__name__} took {end - start:.4f}s")

        return result

    return wrapper


@timer
def slow_sum(n):
    return sum(range(n))


print(slow_sum(1_000_000))