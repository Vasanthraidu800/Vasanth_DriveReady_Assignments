# Output:
# Call #1
# Hi!
# Call #2
# Hi!
# Call #3
# Hi!
# 3


def count_calls(func):
    count = 0

    def wrapper(*args, **kwargs):
        nonlocal count

        count += 1
        print(f"Call #{count}")

        func(*args, **kwargs)

    wrapper.count = 0

    def update_wrapper(*args, **kwargs):
        nonlocal count

        count += 1
        print(f"Call #{count}")

        result = func(*args, **kwargs)

        update_wrapper.count = count
        return result

    return update_wrapper


@count_calls
def say_hi():
    print("Hi!")


say_hi()
say_hi()
say_hi()

print(say_hi.count)