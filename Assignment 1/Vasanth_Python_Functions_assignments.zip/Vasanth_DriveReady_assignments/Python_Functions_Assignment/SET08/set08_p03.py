# Prediction:
# ['Apple', 'banana', 'cherry', 'Date']

words = ["banana", "Apple", "cherry", "Date"]

ans = sorted(words, key=lambda x: x.lower())

print(ans)

# Normally Python sorts capital letters before small letters.
# I convert every word to lowercase only for comparison.
# The original words are not changed, only the sorting is done ignoring case.