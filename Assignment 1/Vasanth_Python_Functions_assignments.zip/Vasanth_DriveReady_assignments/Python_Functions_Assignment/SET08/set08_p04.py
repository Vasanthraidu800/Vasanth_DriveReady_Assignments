# Prediction:
# [20, 20, 20]

funcs = []

for i in range(3):
    funcs.append(lambda: i * 10)

print([f() for f in funcs])

# Fixed version

funcs = []

for i in range(3):
    funcs.append(lambda i=i: i * 10)

print([f() for f in funcs])