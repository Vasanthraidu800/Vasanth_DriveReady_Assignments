# Prediction:
# grade(95) -> A
# grade(82) -> B
# grade(65) -> C
# grade(45) -> D
# grade(20) -> F

grade = lambda m: "A" if m >= 90 else \
                  "B" if m >= 75 else \
                  "C" if m >= 60 else \
                  "D" if m >= 40 else "F"

print(grade(95))
print(grade(82))
print(grade(65))
print(grade(45))
print(grade(20))

