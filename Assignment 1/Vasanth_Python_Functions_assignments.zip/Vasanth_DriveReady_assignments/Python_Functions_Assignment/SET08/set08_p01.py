# Prediction:
# is_even(10)       -> True
# is_leap(2024)     -> True
# is_leap(1900)     -> False
# reverse("python") -> nohtyp
# bigger(10,20)     -> 20
# area_circle(7)    -> 153.93804002589985

is_even = lambda x: x % 2 == 0

is_leap = lambda y: (y % 400 == 0) or (y % 4 == 0 and y % 100 != 0)

reverse = lambda s: s[::-1]

bigger = lambda a, b: a if a > b else b

area_circle = lambda r: 3.141592653589793 * r * r


print(is_even(10))
print(is_leap(2024))
print(is_leap(1900))
print(reverse("python"))
print(bigger(10, 20))
print(area_circle(7))

