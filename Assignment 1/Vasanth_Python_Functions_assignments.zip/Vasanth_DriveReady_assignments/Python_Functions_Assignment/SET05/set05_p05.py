# Prediction:
# ways(1)   -> 1
# ways(2)   -> 2
# ways(3)   -> 3
# ways(4)   -> 5
# ways(5)   -> 8
# ways(10)  -> 89
# ways(100) -> Very large number

from functools import lru_cache

@lru_cache(None)
def ways(n):

    if n == 1:
        return 1

    if n == 2:
        return 2

    return ways(n - 1) + ways(n - 2)


print("ways(1)  =", ways(1))
print("ways(2)  =", ways(2))
print("ways(3)  =", ways(3))
print("ways(4)  =", ways(4))
print("ways(5)  =", ways(5))
print("ways(10) =", ways(10))
print("ways(100) =", ways(100))

# From each step I can go either 1 step or 2 steps.
# So the total ways for step n are the ways to reach n-1 plus the ways to reach n-2.
# @lru_cache remembers old answers, so the same calculation is not done again.