# Prediction:
# digit_sum(12345) -> 15
# digit_sum(9)     -> 9
# digit_sum(100)   -> 1

def digit_sum(n):

    if n < 10:
        return n

    return n % 10 + digit_sum(n // 10)


print("digit_sum(12345) =", digit_sum(12345))
print("digit_sum(9) =", digit_sum(9))
print("digit_sum(100) =", digit_sum(100))

# I take the last digit using %10.
# Then I remove the last digit using //10.
# I keep doing this until only one digit is left.
# Then all the digits get added while returning.