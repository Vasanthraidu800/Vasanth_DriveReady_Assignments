# Prediction:
# flatten([1, [2, 3, [4, [5, 6]], 7], 8])
# -> [1, 2, 3, 4, 5, 6, 7, 8]
#
# flatten([[[[1]]], 2, [[3, [4]]]])
# -> [1, 2, 3, 4]

def flatten(lst):

    ans = []

    def solve(x):

        for i in x:

            if isinstance(i, list):
                solve(i)
            else:
                ans.append(i)

    solve(lst)
    return ans


print(flatten([1, [2, 3, [4, [5, 6]], 7], 8]))
print(flatten([[[[1]]], 2, [[3, [4]]]]))

# I check every element one by one.
# If it is a list, I go inside it again.
# If it is a number, I add it to the answer.
# This continues until there are no more nested lists.