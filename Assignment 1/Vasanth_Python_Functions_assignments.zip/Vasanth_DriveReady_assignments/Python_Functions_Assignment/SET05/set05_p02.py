# Prediction:
# reverse_string("DriveReady") -> ydaeRevirD
# reverse_string("a")          -> a

def reverse_string(s):

    if len(s) <= 1:
        return s

    return s[-1] + reverse_string(s[:-1])


print('reverse_string("DriveReady") =', reverse_string("DriveReady"))
print('reverse_string("a") =', reverse_string("a"))


# I take the last character first.
# Then I call the function for the remaining string.
# This keeps happening until only one character is left.