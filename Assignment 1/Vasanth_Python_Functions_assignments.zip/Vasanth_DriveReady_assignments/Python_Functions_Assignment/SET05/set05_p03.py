# Prediction:
# palindrome("madam")                     -> True
# palindrome("Never odd or even")         -> True
# palindrome("python")                    -> False
# palindrome("Was it a car or a cat I saw") -> True

def palindrome(s):

    s = s.replace(" ", "").lower()

    def check(left, right):

        if left >= right:
            return True

        if s[left] != s[right]:
            return False

        return check(left + 1, right - 1)

    return check(0, len(s) - 1)


print(palindrome("madam"))
print(palindrome("Never odd or even"))
print(palindrome("python"))
print(palindrome("Was it a car or a cat I saw"))

# First I remove all spaces and convert everything to lowercase.
# Then I compare the first and last characters.
# If they are the same, I move one step inside from both sides.
# I keep doing this until all characters are checked.