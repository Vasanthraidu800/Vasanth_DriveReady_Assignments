# Prediction:
# For 3 disks:
# Total moves = 7
#
# For 4 disks:
# Total moves = 15

count = 0

def hanoi(n, source, helper, destination):
    global count

    if n == 1:
        print("Move disk 1:", source, "->", destination)
        count += 1
        return

    hanoi(n - 1, source, destination, helper)

    print("Move disk", n, ":", source, "->", destination)
    count += 1

    hanoi(n - 1, helper, source, destination)


count = 0
hanoi(3, "A", "B", "C")
print("Total moves:", count)

print()

count = 0
hanoi(4, "A", "B", "C")
print("Total moves:", count)

# First move the top n-1 disks to the helper rod.
# Then move the biggest disk to the destination.
# Finally move the n-1 disks from the helper rod to the destination.
# The number of moves should always be 2^n - 1.