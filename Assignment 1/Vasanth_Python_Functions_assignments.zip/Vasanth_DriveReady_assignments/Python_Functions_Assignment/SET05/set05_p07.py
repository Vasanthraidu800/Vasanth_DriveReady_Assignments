# Prediction:
# Found at index 5
# Not found (-1)

def binary_search(arr, left, right, target):

    if left > right:
        return -1

    mid = (left + right) // 2

    if arr[mid] == target:
        return mid

    if target < arr[mid]:
        return binary_search(arr, left, mid - 1, target)

    return binary_search(arr, mid + 1, right, target)


arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91]

ans = binary_search(arr, 0, len(arr) - 1, 23)

if ans == -1:
    print("Not found (-1)")
else:
    print("Found at index", ans)

ans = binary_search(arr, 0, len(arr) - 1, 100)

if ans == -1:
    print("Not found (-1)")
else:
    print("Found at index", ans)
