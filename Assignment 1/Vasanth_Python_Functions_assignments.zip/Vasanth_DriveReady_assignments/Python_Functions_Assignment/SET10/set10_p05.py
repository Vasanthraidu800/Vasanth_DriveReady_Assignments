from functools import reduce

# Input: ["apple", "banana", "apple", "cherry", "banana", "apple"]
# Output: {'apple': 3, 'banana': 2, 'cherry': 1}

words = ["apple", "banana", "apple", "cherry", "banana", "apple"]

frequency = reduce(
    lambda acc, word: {**acc, word: acc.get(word, 0) + 1},
    words,
    {}
)

print(frequency)