# Prediction:
# [32.0, 77.0, 98.6, 212.0, -40.0]

celsius = [0, 25, 37, 100, -40]

fahrenheit = list(map(lambda c: c * 9 / 5 + 32, celsius))

print(fahrenheit)