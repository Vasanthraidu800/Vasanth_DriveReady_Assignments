from functools import reduce

# Input sales data
# Output:
# Total South revenue: Rs 243000
# Total North revenue: Rs 26000

sales = [
    {"product": "Laptop",   "price": 55000, "qty": 3,  "region": "South"},
    {"product": "Mouse",    "price": 500,   "qty": 20, "region": "North"},
    {"product": "Monitor",  "price": 12000, "qty": 5,  "region": "South"},
    {"product": "Keyboard", "price": 1500,  "qty": 12, "region": "South"},
    {"product": "Printer",  "price": 8000,  "qty": 2,  "region": "North"},
]


def calculate_revenue(region):
    return reduce(
        lambda total, sale: total + sale["price"] * sale["qty"],
        map(
            lambda sale: sale,
            filter(lambda sale: sale["region"] == region, sales)
        ),
        0
    )


south_revenue = calculate_revenue("South")
north_revenue = calculate_revenue("North")

print("Total South revenue: Rs", south_revenue)
print("Total North revenue: Rs", north_revenue)