# Prediction:
# 15
# 120
# 9
# Python is powerful
# python

from functools import reduce

nums = [1, 2, 3, 4, 5]

print(reduce(lambda a, b: a + b, nums))
# Built-in: sum(nums)

print(reduce(lambda a, b: a * b, nums))
# Built-in: math.prod(nums)

nums = [3, 7, 2, 9, 4]

print(reduce(lambda a, b: a if a > b else b, nums))
# Built-in: max(nums)

words = ["Python", "is", "powerful"]

print(reduce(lambda a, b: a + " " + b, words))
# Built-in: " ".join(words)

words = ["hi", "python", "is"]

print(reduce(lambda a, b: a if len(a) > len(b) else b, words))
# Built-in: max(words, key=len)