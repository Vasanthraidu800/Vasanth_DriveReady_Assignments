# Prediction:
# ['Ravi: 78', 'Priya: 92', 'Kiran: 45']
# Different lengths:
# ['Ravi: 78', 'Priya: 92']

names = ["Ravi", "Priya", "Kiran"]
marks = [78, 92, 45]

result = list(map(lambda n, m: f"{n}: {m}", names, marks))

print(result)


names = ["Ravi", "Priya", "Kiran"]
marks = [78, 92]

result = list(map(lambda n, m: f"{n}: {m}", names, marks))

print(result)

# map() stops when the shortest iterable ends.
# So the extra elements in the longer list are ignored.