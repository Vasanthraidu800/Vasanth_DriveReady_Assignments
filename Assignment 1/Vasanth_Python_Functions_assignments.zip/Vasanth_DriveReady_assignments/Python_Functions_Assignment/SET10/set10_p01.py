# Prediction:
# [1, 4, 9, 16, 25]
# [1, 2, 3, 42]
# ['RAVI', 'PRIYA']
# [2, 6, 2]

nums = [1, 2, 3, 4, 5]

print(list(map(lambda x: x * x, nums)))

nums = ["1", "2", "3", "42"]

print(list(map(int, nums)))

names = ["ravi", "priya"]

print(list(map(str.upper, names)))

words = ["hi", "python", "is"]

print(list(map(len, words)))