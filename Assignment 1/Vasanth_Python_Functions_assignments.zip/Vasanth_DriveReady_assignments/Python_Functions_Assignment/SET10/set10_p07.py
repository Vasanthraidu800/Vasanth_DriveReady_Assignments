from functools import reduce

# Input: 1 to 10
# Output: 220
# Explanation: (2² + 4² + 6² + 8² + 10²)
#              = 4 + 16 + 36 + 64 + 100 = 220

# Input: 1 to 100
# Output: 171700


def sum_of_squares_of_evens(n):
    return reduce(
        lambda total, x: total + x,
        map(
            lambda x: x * x,
            filter(
                lambda x: x % 2 == 0,
                range(1, n + 1)
            )
        ),
        0
    )


print(sum_of_squares_of_evens(10))
print(sum_of_squares_of_evens(100))