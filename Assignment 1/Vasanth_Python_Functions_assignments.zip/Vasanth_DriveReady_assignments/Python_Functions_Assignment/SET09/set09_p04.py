# Prediction:
# [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]

def is_prime(n):

    if n < 2:
        return False

    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False

    return True


nums = range(1, 51)

print(list(filter(is_prime, nums)))

# I used def instead of lambda because checking prime
# needs multiple statements and a loop.
# Lambda is meant for short one-line functions.