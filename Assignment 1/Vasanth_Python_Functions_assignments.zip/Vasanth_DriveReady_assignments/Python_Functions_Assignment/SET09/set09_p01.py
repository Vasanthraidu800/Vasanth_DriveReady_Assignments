# Prediction:
# [7, 14, 21, 28, 35, 42, 49]
# ['python', 'great']
# ['madam', 'level', 'radar']

nums = list(range(1, 51))

print(list(filter(lambda x: x % 7 == 0, nums)))

words = ["hi", "python", "is", "great", "ok"]

print(list(filter(lambda x: len(x) > 4, words)))

words = ["madam", "python", "level", "code", "radar"]

print(list(filter(lambda x: x == x[::-1], words)))