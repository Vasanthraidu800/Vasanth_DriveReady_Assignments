# Prediction:
# Before fix:
# [4, 5]
# []
#
# After fix:
# [4, 5]
# [4, 5]

# ---------- Before Fix ----------

result = filter(lambda x: x > 3, [1, 2, 3, 4, 5])

print(list(result))
print(list(result))

# The filter object is used only once.
# After the first list() call, it becomes empty.


print()


# ---------- After Fix ----------

result = list(filter(lambda x: x > 3, [1, 2, 3, 4, 5]))

print(result)
print(result)