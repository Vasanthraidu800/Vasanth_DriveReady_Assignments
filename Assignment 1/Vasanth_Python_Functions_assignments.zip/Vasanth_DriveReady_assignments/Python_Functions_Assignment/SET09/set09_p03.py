# Prediction:
# Class average: 72.8
# Above average:
# Priya 92
# Divya 88
# Ravi 78

students = [
    {"name": "Ravi",   "marks": 78},
    {"name": "Priya",  "marks": 92},
    {"name": "Kiran",  "marks": 45},
    {"name": "Divya",  "marks": 88},
    {"name": "Suresh", "marks": 61},
]

avg = sum(s["marks"] for s in students) / len(students)

print("Class average:", avg)
print("Above average:")

ans = list(filter(lambda s: s["marks"] > avg, students))
ans.sort(key=lambda s: s["marks"], reverse=True)

for s in ans:
    print(f'{s["name"]:7} {s["marks"]}')