# Prediction:
# [1, 'hello', [1, 2], True, '0']

data = [0, 1, "", "hello", None, [], [1, 2], False, True, 0.0, "0"]

print(list(filter(None, data)))

# "0" survives because it is a non-empty string, so Python treats it as True.
# 0 does not survive because it is an integer with value 0, so Python treats it as False.