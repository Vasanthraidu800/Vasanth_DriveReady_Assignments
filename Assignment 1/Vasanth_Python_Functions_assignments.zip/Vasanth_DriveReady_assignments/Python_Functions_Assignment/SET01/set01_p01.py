# Prediction:
# Total runs      : 68
# Highest over    : 20
# Lowest over     : 0
# Average per over: 8.5
# Maiden overs    : 1
# Bytes used      : 32

runs = [6, 12, 4, 0, 15, 8, 3, 20]

total_runs = sum(runs)
highest=max(runs)
lowest=min(runs)
average=total_runs/len(runs)
maiden = runs.count(0)
bytes = len(runs)*4

print("Total runs      :", total_runs)
print("Highest over    :", highest)
print("Lowest over     :", lowest)
print("Average per over:", average)
print("Maiden overs    :", maiden)
print("Bytes used      :", bytes)