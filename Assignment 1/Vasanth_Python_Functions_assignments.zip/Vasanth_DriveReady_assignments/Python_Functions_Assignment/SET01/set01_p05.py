# Prediction:
# Output: [1, 2, 3, 4, 7, 8, 9, 10, 15]

a = [1, 4, 7, 9]
b = [2, 3, 8, 10, 15]

i = 0
j = 0
ans = []

while i < len(a) and j < len(b):
    if a[i] < b[j]:
        ans.append(a[i])
        i += 1
    else:
        ans.append(b[j])
        j += 1

while i < len(a):
    ans.append(a[i])
    i += 1

while j < len(b):
    ans.append(b[j])
    j += 1

print(ans)