# Prediction:
# After append  : array('i', [10, 20, 30, 40, 50, 60])
# After insert  : array('i', [10, 15, 20, 30, 40, 50, 60])
# After remove  : array('i', [10, 15, 20, 40, 50, 60])
# After pop     : array('i', [15, 20, 40, 50, 60]) (popped 10)
# After reverse : array('i', [60, 50, 40, 20, 15])

from array import array

arr = array('i', [10, 20, 30, 40, 50])

# 1. Append 60
arr.append(60)
print("After append  :", arr)

# 2. Insert 15 at index 1
arr.insert(1, 15)
print("After insert  :", arr)

# 3. Remove value 30
arr.remove(30)
print("After remove  :", arr)

# 4. Pop element at index 0
popped = arr.pop(0)
print("After pop     :", arr, "(popped", popped, ")")

# 5. Reverse the array
arr.reverse()
print("After reverse :", arr)