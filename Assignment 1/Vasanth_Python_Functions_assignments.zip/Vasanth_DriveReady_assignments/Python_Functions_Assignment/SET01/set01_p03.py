# Prediction:
# Input 1: Second largest = 88
# Input 2: No second largest

nums = [45, 88, 12, 88, 67, 90]

largest = float('-inf')
second = float('-inf')

for num in nums:
    if num > largest:
        second = largest
        largest = num
    elif num > second and num != largest:
        second = num

if second == float('-inf'):
    print("No second largest")
else:
    print("Second largest =", second)


# Second test case
nums = [5, 5, 5]

largest = float('-inf')
second = float('-inf')

for num in nums:
    if num > largest:
        second = largest
        largest = num
    elif num > second and num != largest:
        second = num

if second == float('-inf'):
    print("No second largest")
else:
    print("Second largest =", second)