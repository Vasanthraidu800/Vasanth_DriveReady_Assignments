# Prediction:
# Output: [4, 5, 6, 7, 1, 2, 3]
# Output: [3, 1, 2]

arr = [1, 2, 3, 4, 5, 6, 7]
k = 3

k = k % len(arr)

arr = arr[k:] + arr[:k]

print(arr)


arr = [1, 2, 3]
k = 5

k = k % len(arr)

arr = arr[k:] + arr[:k]

print(arr)