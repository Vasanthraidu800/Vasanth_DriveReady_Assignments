# Output:
# Pushed 10. Size: 1
# Pushed 20. Size: 2
# Pushed 30. Size: 3
# Popped 30. Size: 2
# Popped 20. Size: 1
# 1
# Popped 10. Size: 0
# Stack is empty


def make_stack():
    stack = []

    def push(value):
        stack.append(value)
        print(f"Pushed {value}. Size: {len(stack)}")

    def pop():
        if len(stack) == 0:
            print("Stack is empty")
        else:
            value = stack.pop()
            print(f"Popped {value}. Size: {len(stack)}")

    def size():
        return len(stack)

    return push, pop, size


push, pop, size = make_stack()

push(10)
push(20)
push(30)

pop()
pop()

print(size())

pop()
pop()