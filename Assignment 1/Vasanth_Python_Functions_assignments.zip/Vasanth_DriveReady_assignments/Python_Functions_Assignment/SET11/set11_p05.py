# Output:
# Running setup...
# DONE
# DONE
# DONE


def once(func):
    called = False
    result = None

    def wrapper():
        nonlocal called, result

        if not called:
            result = func()
            called = True

        return result

    return wrapper


def expensive_setup():
    print("Running setup...")
    return "DONE"


setup = once(expensive_setup)

print(setup())
print(setup())
print(setup())