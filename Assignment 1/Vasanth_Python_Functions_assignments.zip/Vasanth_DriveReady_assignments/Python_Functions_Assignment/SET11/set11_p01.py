# Input:
# square = make_power(2)
# cube   = make_power(3)
#
# Output:
# 25
# 27
# 16


def make_power(n):
    def power(x):
        return x ** n
    
    return power


square = make_power(2)
cube = make_power(3)

print(square(5))
print(cube(3))
print(make_power(4)(2))