# Input:
# avg = make_averager()
#
# Output:
# 10.0
# 15.0
# 20.0
# 25.0


def make_averager():
    total = 0
    count = 0

    def averager(value):
        nonlocal total, count

        total += value
        count += 1

        return total / count

    return averager


avg = make_averager()

print(avg(10))
print(avg(20))
print(avg(30))
print(avg(40))