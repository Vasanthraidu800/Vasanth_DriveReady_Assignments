# Output:
# Ravi's balance: 1000
# Deposited 500. Balance: 1500
# Insufficient funds. Balance: 1500
# Withdrew 300. Balance: 1200
# Deposit must be positive
# Ravi's balance: 1200


def create_wallet(name, initial_balance):
    balance = initial_balance   # Hidden variable (cannot access directly)

    def statement():
        print(f"{name}'s balance: {balance}")

    def deposit(amount):
        nonlocal balance

        if amount <= 0:
            print("Deposit must be positive")
        else:
            balance += amount
            print(f"Deposited {amount}. Balance: {balance}")

    def withdraw(amount):
        nonlocal balance

        if amount > balance:
            print(f"Insufficient funds. Balance: {balance}")
        else:
            balance -= amount
            print(f"Withdrew {amount}. Balance: {balance}")

    return statement, deposit, withdraw


statement, deposit, withdraw = create_wallet("Ravi", 1000)

statement()

deposit(500)

withdraw(2000)

withdraw(300)

deposit(-100)

statement()


# Trying to change balance directly:
# balance = 999999
# print(balance)

# Can we change the wallet balance?
# No, because balance is a private variable inside the closure
# The only way to modify it is through deposit() and withdraw()