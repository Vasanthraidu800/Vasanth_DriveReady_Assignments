import stringtools as st


print(st.reverse("python"))
print(st.is_palindrome("madam"))
print(st.count_vowels("education"))
print(st.title_case("ravi kumar"))
print(st.remove_spaces("a b c"))


# Testing from stringtools import *

from stringtools import *

print(reverse("hello"))
print(is_palindrome("level"))

# This will give an error because _clean_string is private
# print(_clean_string("HELLO"))