__all__ = [
    "reverse",
    "is_palindrome",
    "count_vowels",
    "title_case",
    "remove_spaces"
]


# Private helper
def _clean_string(text):
    return text.lower().replace(" ", "")


def reverse(text):
    return text[::-1]


def is_palindrome(text):
    cleaned = _clean_string(text)
    return cleaned == cleaned[::-1]


def count_vowels(text):
    count = 0

    for ch in text.lower():
        if ch in "aeiou":
            count += 1

    return count


def title_case(text):
    return text.title()


def remove_spaces(text):
    return text.replace(" ", "")