import os
from datetime import datetime

folder = os.path.dirname(os.path.abspath(__file__))

print(f"{'File':<25}{'Size':<10}Last Modified")
print("-" * 48)

total = 0

for file in os.listdir(folder):
    if file.endswith(".py"):
        path = os.path.join(folder, file)

        size = os.path.getsize(path)
        modified = os.path.getmtime(path)

        if size >= 1024:
            size_str = f"{size / 1024:.1f} KB"
        else:
            size_str = f"{size} B"

        date = datetime.fromtimestamp(modified)
        date_str = date.strftime("%d-%m-%Y %H:%M")

        print(f"{file:<25}{size_str:<10}{date_str}")

        total += 1

print("-" * 48)
print(f"Total: {total} files")