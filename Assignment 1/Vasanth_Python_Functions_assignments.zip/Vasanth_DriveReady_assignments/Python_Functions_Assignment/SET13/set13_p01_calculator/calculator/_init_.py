__version__ = "1.0.0"

from .basic import add