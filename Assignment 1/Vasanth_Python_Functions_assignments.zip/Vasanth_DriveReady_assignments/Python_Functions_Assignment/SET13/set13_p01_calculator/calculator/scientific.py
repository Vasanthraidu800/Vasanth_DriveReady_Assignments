import math


def power(a, b):
    return a ** b


def square_root(a):
    return math.sqrt(a)


def log(a):
    return math.log(a)