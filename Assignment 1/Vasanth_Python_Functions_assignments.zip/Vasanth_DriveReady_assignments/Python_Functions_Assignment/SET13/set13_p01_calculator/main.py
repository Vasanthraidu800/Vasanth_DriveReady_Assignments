from calculator.basic import add, divide
from calculator.scientific import power, square_root


print(add(10, 5))
print(divide(10, 0))
print(power(2, 10))
print(square_root(144))