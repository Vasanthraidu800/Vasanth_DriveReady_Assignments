# Prediction:
# Local     : I am local
# Enclosing : I am enclosing
# Global    : I am global
# Built-in  : 5

x = "I am global"

def outer():
    x = "I am enclosing"

    def inner():
        x = "I am local"

        print("Local     :", x)
        print("Enclosing :", outer_x)
        print("Global    :", globals()["x"])
        print("Built-in  :", len("hello"))

    outer_x = x
    inner()

outer()

# Note:
# Local means the variable inside the current function.
# Enclosing means the variable from the outer function.
# Global means the variable outside all functions.
# Built-in means Python already gives these functions like len().