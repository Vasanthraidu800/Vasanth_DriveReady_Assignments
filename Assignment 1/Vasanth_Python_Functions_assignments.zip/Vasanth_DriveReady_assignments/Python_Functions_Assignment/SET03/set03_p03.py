# Prediction:
# Version A: 1 2 3
# Version B: 1 2 3

# ---------- Version A (global) ----------

count = 0

def counter_global():
    global count
    count += 1
    return count

print("Version A:", end=" ")
print(counter_global(), counter_global(), counter_global())


# ---------- Version B (nonlocal) ----------

def outer():
    count = 0

    def counter_nonlocal():
        nonlocal count
        count += 1
        return count

    return counter_nonlocal

c = outer()

print("Version B:", end=" ")
print(c(), c(), c())


# Which one is safer?
# nonlocal is safer because the variable is accessible only inside the outer function.
# global variables can be changed from anywhere in the program, making bugs easier to introduce.