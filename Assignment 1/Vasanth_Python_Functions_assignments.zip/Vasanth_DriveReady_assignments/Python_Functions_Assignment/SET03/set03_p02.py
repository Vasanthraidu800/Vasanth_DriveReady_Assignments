# Prediction:
# Booked 3 seats. Remaining: 97
# Booked 10 seats. Remaining: 87
# Only 87 seats left. Booking failed.
# Cancelled 5 seats. Remaining: 92
# 92 seats available out of 100

total = 100
seats = 100

def book(n):
    global seats

    if n <= seats:
        seats -= n
        print("Booked", n, "seats. Remaining:", seats)
    else:
        print("Only", seats, "seats left. Booking failed.")

def cancel(n):
    global seats

    if seats + n <= total:
        seats += n
    else:
        seats = total

    print("Cancelled", n, "seats. Remaining:", seats)

def status():
    print(seats, "seats available out of", total)

book(3)
book(10)
book(200)
cancel(5)
status()