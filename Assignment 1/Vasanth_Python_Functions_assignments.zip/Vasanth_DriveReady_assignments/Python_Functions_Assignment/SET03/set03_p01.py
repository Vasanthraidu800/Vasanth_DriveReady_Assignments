# Puzzle A
# Prediction:
# Error: local variable 'x' referenced before assignment

print("Puzzle A")

x = 10

def f():
    print(x)
    x = 20

try:
    f()
except Exception as e:
    print(e)

# Explanation:
# Since x is assigned inside the function, Python treats it as a local variable.
# print(x) tries to use the local x before it is assigned.


print("\nPuzzle B")

# Prediction:
# 5

x = 5

def f(x):
    x = 10

f(x)
print(x)

# Explanation:
# The function parameter x is local to the function.
# Changing it does not affect the global variable.


print("\nPuzzle C")

# Prediction:
# enclosing

x = "global"

def outer():
    x = "enclosing"

    def inner():
        print(x)

    inner()

outer()

# Explanation:
# inner() uses the x from outer(), not the global x.


print("\nPuzzle D")

# Prediction:
# 99

if True:
    z = 99

print(z)

# Explanation:
# if blocks do not create a new scope in Python.