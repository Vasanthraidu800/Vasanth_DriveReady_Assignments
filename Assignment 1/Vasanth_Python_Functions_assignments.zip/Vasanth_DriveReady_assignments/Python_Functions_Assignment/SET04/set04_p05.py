# Prediction:
# factorial(5)      -> 120
# factorial(0)      -> 1
# factorial(-3)     -> ValueError: Factorial is not defined for negative numbers
# factorial(2.5)    -> TypeError: Expected an integer, got float
# factorial("five") -> TypeError: Expected an integer, got str

def factorial(n):

    if not isinstance(n, int):
        raise TypeError("Expected an integer, got " + type(n).__name__)

    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")

    fact = 1

    for i in range(1, n + 1):
        fact *= i

    return fact


tests = [5, 0, -3, 2.5, "five"]

for x in tests:
    try:
        print("factorial(" + str(x) + ") =", factorial(x))
    except Exception as e:
        print("factorial(" + str(x) + ") ->", type(e).__name__ + ":", e)

# First I check whether the input is an integer.
# Then I check whether it is negative.
# If both checks pass, I calculate the factorial.
# If not, Python raises the correct error.