# Prediction:
# nPr(5, 2)   -> 20
# nCr(5, 2)   -> 10
# nCr(15, 11) -> 1365
# nCr(52, 5)  -> 2598960
# nCr(5, 7)   -> Error: r cannot be greater than n

def factorial(n):
    fact = 1

    for i in range(1, n + 1):
        fact *= i

    return fact


def nPr(n, r):
    if r > n:
        print("Error: r cannot be greater than n")
        return

    ans = factorial(n) // factorial(n - r)
    print(ans)


def nCr(n, r):
    if r > n:
        print("Error: r cannot be greater than n")
        return

    ans = factorial(n) // (factorial(r) * factorial(n - r))
    print(ans)


print("nPr(5, 2) =", end=" ")
nPr(5, 2)

print("nCr(5, 2) =", end=" ")
nCr(5, 2)

print("nCr(15, 11) =", end=" ")
nCr(15, 11)

print("nCr(52, 5) =", end=" ")
nCr(52, 5)

print("nCr(5, 7) =", end=" ")
nCr(5, 7)

# nPr means order matters.
# nCr means order does not matter.
# I first find factorials and then use the formulas.
# If r is bigger than n, the answer is not possible.