# Prediction:
# Terms used : 20
# Computed e : 2.718281828459045
# math.e     : 2.718281828459045
# Difference : 0.00e+00

import math

def factorial(n):
    fact = 1

    for i in range(1, n + 1):
        fact *= i

    return fact


terms = 20
e = 0

for i in range(terms):
    e += 1 / factorial(i)

print("Terms used :", terms)
print("Computed e :", e)
print("math.e     :", math.e)
print("Difference :", format(abs(e - math.e), ".2e"))

# Try with fewer terms
terms = 5
e = 0

for i in range(terms):
    e += 1 / factorial(i)

print("\nUsing 5 terms :", e)

terms = 10
e = 0

for i in range(terms):
    e += 1 / factorial(i)

print("Using 10 terms:", e)

# e is found by adding 1/factorial(i).
# As I use more terms, the answer gets closer to math.e.
# Even with a few terms, the value becomes very accurate.