# Prediction:
# Input: 10   Output: 2
# Input: 25   Output: 6
# Input: 100  Output: 24
# Input: 1000 Output: 249

def trailing_zeros(n):
    count = 0

    while n > 0:
        n = n // 5
        count += n

    print(count)


trailing_zeros(10)
trailing_zeros(25)
trailing_zeros(100)
trailing_zeros(1000)

# My understanding:
# Every trailing zero comes from one 5 and one 2.
# There are always more 2s than 5s in n!.
# So I only count how many times 5 appears.
# I keep dividing by 5 because numbers like 25 and 125 have more than one 5.