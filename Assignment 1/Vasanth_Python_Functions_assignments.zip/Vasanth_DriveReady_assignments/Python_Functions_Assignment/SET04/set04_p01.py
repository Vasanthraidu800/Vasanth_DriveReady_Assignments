# Prediction:
# Prints factorials from 0 to 15 along with the number of digits.

fact = 1

print(f"{'n':>3} | {'n!':>25} | {'digits':>6}")
print("----+---------------------------+-------")

for i in range(16):

    if i == 0:
        fact = 1
    else:
        fact *= i

    print(f"{i:>3} | {fact:>25,} | {len(str(fact)):>6}")


# len(str(fact)) tells how many digits are in the factorial.