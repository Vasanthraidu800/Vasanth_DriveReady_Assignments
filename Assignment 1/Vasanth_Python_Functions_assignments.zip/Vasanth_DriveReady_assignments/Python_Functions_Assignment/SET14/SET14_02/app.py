import mathutils

print("App started")

print(300)