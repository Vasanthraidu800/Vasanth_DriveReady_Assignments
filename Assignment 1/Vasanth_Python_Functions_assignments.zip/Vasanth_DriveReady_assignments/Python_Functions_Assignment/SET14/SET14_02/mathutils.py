def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

if __name__ == "__main__":
    print("Testing add:", add(5, 3))
    print("Testing subtract:", subtract(5, 3))