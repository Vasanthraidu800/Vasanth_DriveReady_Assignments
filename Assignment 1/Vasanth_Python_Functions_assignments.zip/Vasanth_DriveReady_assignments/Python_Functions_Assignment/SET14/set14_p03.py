def c_to_f(c):
    return c * 9 / 5 + 32


def f_to_c(f):
    return (f - 32) * 5 / 9


if __name__ == "__main__":
    assert c_to_f(0) == 32
    assert round(c_to_f(37), 1) == 98.6
    assert f_to_c(32) == 0
    assert round(f_to_c(98.6), 1) == 37.0

    print("All self-tests passed")
    print(f"0°C  = {c_to_f(0):.1f} °F")
    print(f"37°C = {c_to_f(37):.1f} °F")