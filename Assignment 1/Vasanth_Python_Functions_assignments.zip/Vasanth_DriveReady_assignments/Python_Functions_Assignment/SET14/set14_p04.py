# 1. Imports
import math


# 2. Constants
PI = 3.14


# 3. Functions
def area_of_circle(r):
    return PI * r * r


def main():
    r = float(input("Enter radius: "))
    area = area_of_circle(r)
    print("Area:", area)


# 5. Main guard
if __name__ == "__main__":
    main()
    
# main() keeps the program logic organized in one function and makes the code easier to test or reuse.
# It also keeps the main guard clean and makes it clear where program execution starts.