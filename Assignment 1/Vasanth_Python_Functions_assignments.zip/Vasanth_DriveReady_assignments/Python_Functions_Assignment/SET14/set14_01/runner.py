import demo

print("Runner finished")

# When demo.py is run directly, __name__ is "__main__".
# When demo.py is imported into runner.py, __name__ becomes "demo".
# Therefore, demo.py prints "__main__" when run directly and "demo"
# when imported as a module.