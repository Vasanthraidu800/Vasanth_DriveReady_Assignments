# Prediction:
# ['pen']
# ['book']
# ['bag']

# Bug:
# The default list is created only once.
# Every function call uses the same list, so items keep getting added.

def add_to_cart(item, cart=None):
    if cart is None:
        cart = []

    cart.append(item)
    return cart


print(add_to_cart("pen"))
print(add_to_cart("book"))
print(add_to_cart("bag"))