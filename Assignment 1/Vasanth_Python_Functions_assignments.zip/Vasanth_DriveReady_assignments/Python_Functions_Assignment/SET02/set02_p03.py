# Prediction:
# city=hyderabad&rating=4&veg=True
#

def build_query(**filters):
    query = ""

    for key, value in filters.items():
        if query != "":
            query += "&"
        query += str(key) + "=" + str(value)

    print(query)


build_query(city="hyderabad", rating=4, veg=True)
build_query()