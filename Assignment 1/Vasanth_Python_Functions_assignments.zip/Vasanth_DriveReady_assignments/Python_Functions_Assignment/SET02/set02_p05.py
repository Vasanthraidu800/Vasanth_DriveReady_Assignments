# Prediction:
# Student : Priya
# Section : A
# Year    : 2
# Marks   : 85, 92, 78, 90
# Total   : 345
# Average : 86.25
# Result  : PASS

def report(name, *marks, **details):
    print("Student :", name)
    print("Section :", details["section"])
    print("Year    :", details["year"])

    print("Marks   :", end=" ")
    for i in range(len(marks)):
        if i != len(marks) - 1:
            print(marks[i], end=", ")
        else:
            print(marks[i])

    total = sum(marks)
    avg = total / len(marks)

    print("Total   :", total)
    print("Average :", avg)

    if avg >= 40:
        print("Result  : PASS")
    else:
        print("Result  : FAIL")


report("Priya", 85, 92, 78, 90, section="A", year=2)