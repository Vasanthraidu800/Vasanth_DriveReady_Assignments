# Prediction:
# Customer : Ravi
# Items ordered (3):
#   1. Biryani
#   2. Coke
#   3. Gulab Jamun
# Charges:
#   delivery : 40
#   gst : 25
#   discount : 50

def place_order(customer, *items, **charges):
    print("Customer :", customer)

    print("Items ordered (" + str(len(items)) + "):")
    for i in range(len(items)):
        print(" ", i + 1, ".", items[i], sep="")

    print("Charges:")
    for key, value in charges.items():
        print(" ", key, ":", value)


place_order(
    "Ravi",
    "Biryani",
    "Coke",
    "Gulab Jamun",
    delivery=40,
    gst=25,
    discount=50
)