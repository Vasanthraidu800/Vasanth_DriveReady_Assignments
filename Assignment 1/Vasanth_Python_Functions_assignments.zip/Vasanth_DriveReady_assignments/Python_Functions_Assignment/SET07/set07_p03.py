# Prediction:
# 13
# 7
# 30
# 3.3333333333333335
# Unknown operator: %

def add(a, b):
    return a + b

def sub(a, b):
    return a - b

def mul(a, b):
    return a * b

def div(a, b):
    return a / b


ops = {
    "+": add,
    "-": sub,
    "*": mul,
    "/": div
}


def calculate(a, b, op):

    if op in ops:
        return ops[op](a, b)

    return "Unknown operator: " + op


print(calculate(10, 3, "+"))
print(calculate(10, 3, "-"))
print(calculate(10, 3, "*"))
print(calculate(10, 3, "/"))
print(calculate(10, 3, "%"))

# Instead of many if/elif statements, I store functions in a dictionary.
# The operator is used as the key.
# Then I simply call the required function using that key.