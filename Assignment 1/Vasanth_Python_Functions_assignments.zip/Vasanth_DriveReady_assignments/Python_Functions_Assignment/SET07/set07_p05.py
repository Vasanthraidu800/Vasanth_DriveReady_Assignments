# Prediction:
# Starting with: '   Ravi Kumar Sharma   '
# after clean          : 'Ravi Kumar Sharma'
# after to_lower       : 'ravi kumar sharma'
# after remove_spaces  : 'ravi_kumar_sharma'
# after add_prefix     : 'user_ravi_kumar_sharma'
# Final: user_ravi_kumar_sharma

def clean(text):
    return text.strip()

def to_lower(text):
    return text.lower()

def remove_spaces(text):
    return text.replace(" ", "_")

def add_prefix(text):
    return "user_" + text

def pipeline(text, *operations):

    print("Starting with:", repr(text))

    for op in operations:
        text = op(text)
        print(f"after {op.__name__:15}: {repr(text)}")

    print("Final:", text)


pipeline(
    "   Ravi Kumar Sharma   ",
    clean,
    to_lower,
    remove_spaces,
    add_prefix
)

# I pass many functions using *operations.
# Each function changes the text one by one.
# The output of one function becomes the input for the next.
# This is called a pipeline.