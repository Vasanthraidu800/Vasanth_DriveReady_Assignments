# Prediction:
# apply_twice(lambda x: x + 3, 10) -> 16
# apply_twice(lambda x: x * 2, 5)  -> 20
# apply_twice(str.upper, "hi")     -> HI

def apply_twice(func, value):
    return func(func(value))


print(apply_twice(lambda x: x + 3, 10))
print(apply_twice(lambda x: x * 2, 5))
print(apply_twice(str.upper, "hi"))

# The function is called two times.
# First it works on the original value.
# Then it works again on the result from the first call.