# Prediction:
# First list: sorted by runs (highest first)
# Second list: sorted by team, then runs (highest first)
# Third list: sorted by length of player name

players = [
    {"name": "Kohli",   "runs": 741, "team": "RCB"},
    {"name": "Gill",    "runs": 890, "team": "GT"},
    {"name": "Rahul",   "runs": 616, "team": "LSG"},
    {"name": "Jaiswal", "runs": 625, "team": "RR"},
    {"name": "Samson",  "runs": 616, "team": "RR"},
]

print("By runs (high to low):")

a = sorted(players, key=lambda p: p["runs"], reverse=True)

for p in a:
    print(f'{p["name"]:10} {p["runs"]}')

print()

print("By team, then runs (high to low):")

b = sorted(players, key=lambda p: (p["team"], -p["runs"]))

for p in b:
    print(f'{p["team"]:4} {p["name"]:10} {p["runs"]}')

print()

print("By name length:")

c = sorted(players, key=lambda p: len(p["name"]))

for p in c:
    print(p["name"], end=" ")

# I can tell sorted() how to arrange data using key.
# reverse=True sorts numbers from high to low.
# A tuple lets me sort using more than one condition.
# Here team is checked first, then runs inside the same team.