# Prediction:
# Before fix:
# RecursionError: maximum recursion depth exceeded
# After fix:
# ValueError: Factorial is not defined for negative numbers


# ---------- Before Fix ----------

def factorial(n):

    if n == 0:
        return 1

    return n * factorial(n - 1)


try:
    print(factorial(-5))
except Exception as e:
    print(type(e).__name__ + ":", e)


# For -5, the function goes to -6, -7, -8...
# It never reaches 0, so the recursion never stops.
# After many calls, Python gives a RecursionError.


print()


# ---------- After Fix ----------

def factorial(n):

    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")

    if n == 0:
        return 1

    return n * factorial(n - 1)


try:
    print(factorial(-5))
except Exception as e:
    print(type(e).__name__ + ":", e)


# Before checking the base case, I should check for invalid input.
# If the number is negative, I stop immediately by raising a ValueError.
# This prevents infinite recursion.