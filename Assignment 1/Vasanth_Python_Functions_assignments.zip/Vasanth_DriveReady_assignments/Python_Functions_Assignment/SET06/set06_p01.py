# Prediction:
# factorial(5)  -> 120
# factorial(0)  -> 1
# factorial(10) -> 3628800

def factorial(n):

    if n == 0:
        return 1

    return n * factorial(n - 1)


print("factorial(5) =", factorial(5))
print("factorial(0) =", factorial(0))
print("factorial(10) =", factorial(10))

# If n becomes 0, I return 1.
# Otherwise I multiply n with the factorial of n-1.
# The function keeps calling itself until it reaches 0.