# Prediction:
# power(2,10)      -> 1024
# power(5,0)       -> 1
# power(3,4)       -> 81
# fast_power(2,30) -> 1073741824
# fast_power will use much fewer function calls.

normal_calls = 0
fast_calls = 0

def power(x, n):
    global normal_calls
    normal_calls += 1

    if n == 0:
        return 1

    return x * power(x, n - 1)


def fast_power(x, n):
    global fast_calls
    fast_calls += 1

    if n == 0:
        return 1

    half = fast_power(x, n // 2)

    if n % 2 == 0:
        return half * half

    return x * half * half


print("power(2,10) =", power(2, 10))
print("power(5,0) =", power(5, 0))
print("power(3,4) =", power(3, 4))
print()

print("fast_power(2,30) =", fast_power(2, 30))
print()

print("Normal calls :", normal_calls)
print("Fast calls   :", fast_calls)

# power() reduces n by 1 every time, so it makes many recursive calls.
# fast_power() divides n by 2 each time, so it reaches the base case much faster.
# That's why divide-and-conquer is much more efficient.