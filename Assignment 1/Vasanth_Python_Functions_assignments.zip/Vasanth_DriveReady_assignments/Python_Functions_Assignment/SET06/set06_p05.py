# Prediction:
# double_factorial(8) -> 384
# double_factorial(7) -> 105
# double_factorial(1) -> 1
# double_factorial(0) -> 1

def double_factorial(n):

    if n == 0 or n == 1:
        return 1

    return n * double_factorial(n - 2)


print("double_factorial(8) =", double_factorial(8))
print("double_factorial(7) =", double_factorial(7))
print("double_factorial(1) =", double_factorial(1))
print("double_factorial(0) =", double_factorial(0))

# Instead of subtracting 1 like normal factorial,
# I subtract 2 every time.
# The recursion stops when n becomes 0 or 1.
# This multiplies numbers having the same parity (even or odd).