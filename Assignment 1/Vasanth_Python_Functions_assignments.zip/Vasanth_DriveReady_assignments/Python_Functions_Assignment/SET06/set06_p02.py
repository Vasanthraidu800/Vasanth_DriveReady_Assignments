# Prediction:
# Shows every recursive call.
# Shows when the base case is reached.
# Shows how the answer is built while returning.
# Final answer: 24

def factorial(n, depth=0):

    print("|  " * depth + f"factorial({n}) called")

    if n == 1:
        print("|  " * depth + "BASE CASE -> returning 1")
        return 1

    print("|  " * depth + f"needs {n} * factorial({n-1}) ... waiting")

    ans = factorial(n - 1, depth + 1)

    print("|  " * depth + f"got {ans}, so {n} * {ans} = {n * ans}")

    return n * ans


ans = factorial(4)

print("\nFinal answer:", ans)

# The function keeps calling itself until it reaches the base case.
# After that, each call returns one by one.
# The answer is built while coming back from the recursive calls.