from array import array
from functools import reduce
from time import perf_counter

operation_count = 0


def count_operations(func):
    def wrapper(*args, **kwargs):
        global operation_count
        operation_count += 1
        return func(*args, **kwargs)
    return wrapper


def timer(func):
    def wrapper(*args, **kwargs):
        start = perf_counter()
        result = func(*args, **kwargs)
        end = perf_counter()
        print(f"\n[TIMER] {func.__name__} ran in {(end - start) * 1000:.2f} ms")
        return result
    return wrapper


def factorial(n):
    ans = 1
    for i in range(1, n + 1):
        ans *= i
    return ans


def ncr(n, r):
    if r == 0 or r == n:
        return 1
    return ncr(n - 1, r - 1) + ncr(n - 1, r)


def flatten(data):
    result = []

    for item in data:
        if isinstance(item, list):
            result.extend(flatten(item))
        else:
            result.append(item)

    return result


def get_category(total):
    if total >= 1000:
        return "PLATINUM"
    elif total >= 500:
        return "GOLD"
    return "SILVER"


def booking_counter():
    count = 0

    def counter():
        nonlocal count
        count += 1
        return count

    return counter


def summarise(data, *metrics, **kwargs):
    result = {}

    for metric in metrics:
        result[metric.__name__] = metric(data)

    result.update(kwargs)

    return result


def total_seats(data):
    return sum(map(lambda x: x["seats"], data))


def total_revenue(data):
    totals = list(map(lambda x: x["seats"] * x["price"], data))
    return sum(totals)


def highest_booking(data):
    booking = max(data, key=lambda x: x["seats"] * x["price"])
    return booking["name"], booking["seats"] * booking["price"]


def movie_names(data):
    movies = reduce(
        lambda result, booking: result + [booking["movie"]]
        if booking["movie"] not in result
        else result,
        data,
        []
    )

    return movies


def filter_expensive(data):
    return list(filter(lambda x: x["price"] >= 250, data))


def movie_group(data):
    groups = reduce(
        lambda result, booking: {
            **result,
            booking["movie"]: result.get(booking["movie"], []) + [booking["name"]]
        },
        data,
        {}
    )

    return groups


@timer
@count_operations
def generate_report(data):
    show_timings = array("i", [9, 12, 15, 18, 21])

    totals = list(map(lambda x: x["seats"] * x["price"], data))

    for i in range(len(data)):
        data[i]["total"] = totals[i]
        data[i]["category"] = get_category(totals[i])

    print("=" * 60)
    print("              PVR CINEMAS - BOOKING REPORT")
    print("=" * 60)

    print()
    print("Show timings array :", show_timings)
    print("Bytes used         :", show_timings.itemsize * len(show_timings))

    print()
    print(f"{'Name':<10}{'Movie':<15}{'Seats':<7}{'Price':<8}{'Total':<8}Category")
    print("-" * 57)

    for booking in data:
        print(
            f"{booking['name']:<10}"
            f"{booking['movie']:<15}"
            f"{booking['seats']:<7}"
            f"{booking['price']:<8}"
            f"{booking['total']:<8}"
            f"{booking['category']}"
        )

    print()
    print("Metrics:")

    summary = summarise(
        data,
        total_seats,
        total_revenue,
        highest_booking,
        total_bookings=len(data)
    )

    print(f"  Total bookings    : {summary['total_bookings']}")
    print(f"  Total seats sold  : {summary['total_seats']}")
    print(f"  Total revenue     : Rs {summary['total_revenue']:,}")

    average = summary["total_revenue"] / summary["total_seats"]
    print(f"  Average per ticket: Rs {average:.2f}")

    name, amount = summary["highest_booking"]
    print(f"  Highest booking   : {name} (Rs {amount})")

    print()
    print("Bookings by movie:")

    groups = movie_group(data)

    for movie in sorted(groups):
        print(f"  {movie:<7}: {', '.join(groups[movie])}")

    print()
    print("Seat arrangement combinations:")
    print(f"  Ways to choose 3 seats from 10: {ncr(10, 3)}")
    print(f"  5! = {factorial(5)}")

    filter_expensive(data)

def main():
    bookings = [
        {"name": "Ravi", "movie": "RRR", "seats": 3, "price": 250},
        {"name": "Priya", "movie": "Kalki", "seats": 2, "price": 300},
        {"name": "Kiran", "movie": "Salaar", "seats": 5, "price": 200},
        {"name": "Divya", "movie": "RRR", "seats": 1, "price": 250},
        {"name": "Suresh", "movie": "Kalki", "seats": 4, "price": 300}
    ]

    generate_report(bookings)

    print(f"Total operations logged: {operation_count}")
    print("=" * 60)


if __name__ == "__main__":
    main()